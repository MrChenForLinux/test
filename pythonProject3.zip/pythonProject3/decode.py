from typing import List, Dict, Optional

from PIL import Image
from pyzbar import pyzbar

import asn1
import json


def base45decode_nl(s: str) -> bytes:
    base45_nl_charset = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:"

    s_len = len(s)
    res = 0
    for i, c in enumerate(s):
        f = base45_nl_charset.index(c)
        w = 45 ** (s_len - i - 1)
        res += f * w
    return res.to_bytes((res.bit_length() + 7) // 8, byteorder='big')


def base45decode_nl(s: str) -> bytes:
    base45_nl_charset = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:"

    s_len = len(s)
    res = 0
    for i, c in enumerate(s):
        f = base45_nl_charset.index(c)
        w = 45 ** (s_len - i - 1)
        res += f * w
    return res.to_bytes((res.bit_length() + 7) // 8, byteorder='big')


def asn1decode(d: asn1.Decoder) -> List:
    res = []
    while not d.eof():
        tag = d.peek()
        if tag.typ == asn1.Types.Primitive:
            tag, value = d.read()
            res.append(value)
        elif tag.typ == asn1.Types.Constructed:
            d.enter()
            res.append(asn1decode(d))
            d.leave()
    return res


class NLDomesticCovidCertSerialization:
    DisclosureTimeSeconds: int
    C: int
    A: int
    EResponse: int
    VResponse: int
    AResponse: int
    ADisclosed: List[int]

    def __init__(self, data: List):
        self.DisclosureTimeSeconds = data[0]
        self.C = data[1]
        self.A = data[2]
        self.EResponse = data[3]
        self.VResponse = data[4]
        self.AResponse = data[5]
        self.ADisclosed = data[6]

    def decode_metadata(self) -> List:
        b = NLDomesticCovidCertSerialization.decode_int(self.ADisclosed[0])
        d = asn1.Decoder()
        d.start(b)
        return asn1decode(d)[0]

    def decode_attributes(self) -> Dict[str, str]:
        res = {}
        attrs = ['isSpecimen',
                 'isPaperProof',
                 'validFrom',
                 'validForHours',
                 'firstNameInitial',
                 'lastNameInitial',
                 'birthDay',
                 'birthMonth']
        for i, x in enumerate(self.ADisclosed[1:]):
            res[attrs[i]] = NLDomesticCovidCertSerialization.decode_int(x).decode('utf-8')
        return res

    @staticmethod
    def decode_int(value: int) -> Optional[bytes]:
        if not value & 1:
            return None
        else:
            v = value >> 1
            return v.to_bytes((v.bit_length() + 7) // 8, byteorder='big')

qr_img = Image.open('nl-domestic-covid-cert-example.png')
qr_result = pyzbar.decode(qr_img)
qr_data = qr_result[0].data
b45_data = qr_data[4:]
b45_str = b45_data.decode(encoding='utf-8')
b45_decoded = base45decode_nl(b45_str)
asn1_decoder = asn1.Decoder()
asn1_decoder.start(b45_decoded)
asn1_obj = asn1decode(asn1_decoder)[0]
asn1_data = NLDomesticCovidCertSerialization(asn1_obj)
print(asn1_data.decode_metadata())
print(json.dumps(asn1_data.decode_attributes(), indent=4))
