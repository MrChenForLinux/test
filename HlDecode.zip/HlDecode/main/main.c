/*
*@file main.c
*/

#include "raw_circle_asn.h"
#define BUFF_SIZE (32)

void print_raw_circle(const RawCircle_t *circle)
{
    printf("x:%ld y:%ld r:%lf\n", circle->x, circle->y, circle->r);
}

int main()
{
    RawCircle_t circle = {0};
    RawCircle_t new_circle = {0};
    uint8_t buff[BUFF_SIZE] = {0};
    uint32_t consumed_data_size = 0;
    enum asn_dec_rval_code_e error;
    int ret = 0;

    circle.x = 3;
    circle.y = 4;
    circle.r = 5.5;

    print_raw_circle(&circle);

    ret = asn_encode_raw_circle(&circle, buff, BUFF_SIZE, &consumed_data_size);
    assert(ret == 0);

    ret = asn_decode_raw_circle(buff, BUFF_SIZE, &new_circle, &consumed_data_size, &error);
    assert(ret == 0);
    print_raw_circle(&new_circle);

    return 0;
}
