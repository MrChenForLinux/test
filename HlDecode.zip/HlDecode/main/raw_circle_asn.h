/*
*@file raw_circle_asn.h
*/
#ifndef RAW_CIRCLE_ASN_H
#define RAW_CIRCLE_ASN_H

#include "asn_application.h"
#include "RawCircle.h"
#include <stdlib.h>

/**
 * @brief:convert RawCircle_t to uint8_t raw_data
*/
extern int32_t asn_encode_raw_circle(const RawCircle_t *raw_circle_asn, uint8_t *raw_data,
                                     uint32_t raw_data_size, uint32_t *consumed_data_size);

/**
 * @brief: convert uint8_t raw_data to RawCircle_t 
*/
extern int32_t asn_decode_raw_circle(const uint8_t *raw_data, uint32_t raw_data_size, RawCircle_t *raw_circle,
                                     uint32_t *consumed_data_size, enum asn_dec_rval_code_e *error_code);

#endif
