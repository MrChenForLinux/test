/*
*@file raw_circle_asn.c
*/

#include "raw_circle_asn.h"

/* copy from asn_application.c */
struct overrun_encoder_key
{
    void *buffer;
    uint32_t buffer_size;
    uint32_t computed_size;
};

static int overrun_encoder_cb(const void *data, size_t size, void *keyp)
{
    struct overrun_encoder_key *key = keyp;

    if ((key->computed_size + size) > key->buffer_size)
    {
        /*
         * Avoid accident on the next call:
         * stop adding bytes to the buffer.
         */
        key->buffer_size = 0;
    }
    else
    {
        memcpy(((char *)key->buffer + key->computed_size), data, size);
    }
    key->computed_size += (uint32_t)size;

    return 0;
}

extern int32_t asn_encode_raw_circle(const RawCircle_t *raw_circle_asn, uint8_t *raw_data,
                                     uint32_t raw_data_size, uint32_t *consumed_data_size)
{
    int32_t ret = 0;
    struct overrun_encoder_key callback_key;
    asn_enc_rval_t result = {0};

    memset(raw_data, 0, raw_data_size);
    memset(&callback_key, 0, sizeof(callback_key));
    callback_key.buffer = (void *)raw_data;
    callback_key.buffer_size = raw_data_size;

    result = asn_encode(NULL, ATS_BER, &asn_DEF_RawCircle, (const void *)raw_circle_asn, overrun_encoder_cb,
                        &callback_key);
    if (0 <= result.encoded)
    {
        assert(result.encoded == callback_key.computed_size);
        *consumed_data_size = result.encoded;
        if (result.encoded < raw_data_size)
        {
            ret = 0;
        }
        else
        {
            *consumed_data_size += 1;
            ret = -1;
        }
    }
    else
    {
        *consumed_data_size = 0;
        ret = -1;
    }

    return ret;
}

extern int32_t asn_decode_raw_circle(const uint8_t *raw_data, uint32_t raw_data_size, RawCircle_t *raw_circle,
                                     uint32_t *consumed_data_size, enum asn_dec_rval_code_e *error_code)
{
    int32_t ret = 0;
    asn_dec_rval_t result;

    memset(raw_circle, 0, sizeof(*raw_circle));
    result = asn_decode(NULL, ATS_BER, &asn_DEF_RawCircle, (void **)&raw_circle, raw_data, raw_data_size);

    *error_code = result.code;

    if (RC_OK == result.code)
    {
        *consumed_data_size = result.consumed;
        ret = 0;
    }
    else
    {
        *consumed_data_size = 0;
        ret = -1;
    }

    return ret;
}

